setwd("C:\\Users\\Vidhurshan\\OneDrive\\Desktop\\IT24102266 LAB7")


punif(10,min=0,max=40,lower.tail=FALSE)-
  punif(25,min=0,max=40,lower.tail=FALSE)



pexp(2,rate=1/3,lower.tail = TRUE)


pnorm(130,mean=100,sd=15,lower.tail=FALSE)


qnorm(0.95,mean=100,sd=15)

