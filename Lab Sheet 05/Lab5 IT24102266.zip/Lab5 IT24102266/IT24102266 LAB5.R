setwd("C:\\Users\\Vidhurshan\\OneDrive\\Desktop\\Lab5 IT24102266")

data <- read.table("Exercise - Lab 05.txt", header = TRUE, sep = ",")

names(data)[1] <- "x1"


histogram <- hist(data$x1,
                  main = "Histogram for Delivery Times = x1",
                  breaks = seq(20, 70, length = 8),
                  right = FALSE)

breaks <- round(histogram$breaks)
freq   <- histogram$counts
mids   <- histogram$mids

classes <- c()
for(i in 1:(length(breaks)-1)){
  classes[i] <- paste0("[", breaks[i], ",", breaks[i+1], ")")
}

freq_table <- cbind(Classes = classes, Frequency = freq)
print(freq_table)

plot(mids, freq, type = 'o',
     main = "Frequency Polygon for Delivery Time",
     xlab = "Delivery Times",
     ylab = "Frequency",
     ylim = c(0, max(freq)))
