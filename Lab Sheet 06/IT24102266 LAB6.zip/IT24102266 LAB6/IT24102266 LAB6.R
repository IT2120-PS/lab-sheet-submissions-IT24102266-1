setwd("C:\\Users\\Vidhurshan\\OneDrive\\Desktop\\IT24102266 LAB6")

pbinom(46,50,0.85,lower.tail = FALSE)

dpois(15,12)
